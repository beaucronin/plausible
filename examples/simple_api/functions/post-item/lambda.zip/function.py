import plausible as pbl


@pbl.resource("plausible_function.post_item")
def handler():
    trigger = pbl.function.current_trigger
    item_obj = trigger.payload
    
    return True
