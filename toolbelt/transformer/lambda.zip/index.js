var jsonata = require("jsonata");

exports.handler = async function(event, context) {
    var expression = jsonata('{"name": FirstName & " " & Surname,  "mobile": Phone[type = "mobile"].number}');
    return expression.evaluate(event);
}